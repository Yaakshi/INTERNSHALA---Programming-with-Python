#setup file

from setuptools import setup

setup(name='M03 Assignment Basics of Programming in Python', 
version='1.0', 
description='A package to calculate expenses when you hang-out with friends.',
url='#',
author='internshala',
author_email='internshala@internshala.com',
license='MIT',
packages=['M03 Assignment Basics of Programming in Python'],
zip_safe=False)